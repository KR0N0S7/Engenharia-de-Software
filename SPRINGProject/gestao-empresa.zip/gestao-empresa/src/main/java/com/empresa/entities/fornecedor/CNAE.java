//package com.empresa.entities.fornecedor;
//
//public class CNAE {
//
//	private String numero;
//	private Fornecedor fornecedor;
//	
//	public String getNumero() {		return numero;	}
//	public void setNumero(String numero) {		this.numero = numero;	}
//	public Fornecedor getFornecedor() {		return fornecedor;	}
//	public void setFornecedor(Fornecedor fornecedor) {		this.fornecedor = fornecedor;	}
//}
