//package com.empresa.entities.fornecedor;
//
//import java.util.List;
//
//public class Pessoa {
//
//	private String nome;
//	private List<Usuario> usuarios;
//	
//	public String getNome() {	return nome;	}
//	public void setNome(String nome) {		this.nome = nome;	}
//	public List<Usuario> getUsuarios() {	return usuarios;	}
//	public void setUsuarios(List<Usuario> usuarios) {	this.usuarios = usuarios;	}
//}
