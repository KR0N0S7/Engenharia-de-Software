package com.empresa.entities.fornecedor;

public enum TipoFornecimento {

	VENDA, SERVICO;
}
