//package com.empresa.entities.fornecedor;
//
//public class Departamento {
//
//	private String descricao;
//	private Contato contato;
//	
//	public String getDescricao() {	return descricao;	}
//	public void setDescricao(String descricao) {	this.descricao = descricao;	}
//	public Contato getContato() {	return contato;	}
//	public void setContato(Contato contato) {	this.contato = contato;	}
//}
