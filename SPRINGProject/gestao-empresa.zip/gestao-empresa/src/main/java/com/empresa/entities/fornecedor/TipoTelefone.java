//package com.empresa.entities.fornecedor;
//
//public class TipoTelefone {
//
//	private String descricao;
//	private Telefone telefone;
//	
//	public String getDescricao() {	return descricao;	}
//	public void setDescricao(String descricao) {	this.descricao = descricao;	}
//	public Telefone getTelefone() {		return telefone;	}
//	public void setTelefone(Telefone telefone) {	this.telefone = telefone;	}
//}
